import { Component } from "@angular/core";

@Component({
    selector : "app.server",
    styleUrls : ["server.component.css"],
    templateUrl : "./server.component.html"
} )

export class ServerComponent{

}